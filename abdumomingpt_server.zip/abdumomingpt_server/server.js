const express = require('express');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/', rateLimit({ windowMs: 60 * 1000, limit: 15, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.post('/api/chat', async (req, res) => {
  try {
    const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
    if (!message) return res.status(400).json({ error: 'Savol bo‘sh bo‘lmasin.' });
    if (message.length > 6000) return res.status(400).json({ error: 'Savol juda uzun (6000 belgigacha yubor).' });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'Server egasi API kalitini hali sozlamagan.' });
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
        instructions: 'Sen ABDUMOʻMINGPT nomli foydali, aniq va muloyim o‘zbekcha AI yordamchisan. Foydalanuvchiga uning tilida javob ber. Javoblarni sodda va foydali qil.',
        input: message,
        max_output_tokens: 900
      })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error('OpenAI API status:', response.status);
      return res.status(502).json({ error: 'AI xizmatida xatolik. Server egasi API hisobini va limitlarni tekshirsin.' });
    }
    const answer = (data.output || []).flatMap(item => item.content || []).filter(item => item.type === 'output_text').map(item => item.text).join('\n').trim();
    return res.json({ answer: answer || 'Javob matni olinmadi, qayta urinib ko‘r.' });
  } catch (err) {
    console.error('Chat route error:', err.message);
    return res.status(500).json({ error: 'Serverda xatolik yuz berdi.' });
  }
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ABDUMOʻMINGPT running on port ${port}`));
