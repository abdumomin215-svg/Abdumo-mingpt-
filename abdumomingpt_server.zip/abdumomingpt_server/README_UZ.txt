ABDUMOʻMINGPT — server orqali AI ulash

MUHIM: Bu loyiha backend server talab qiladi. API kalitini HTML faylga yoki GitHub ommaviy repozitoriyasiga yozmang.

Render orqali joylash:
1. Ushbu papkadagi fayllarni GitHub repozitoriyasiga yuklang (API kalitisiz).
2. Render.com saytida New + > Web Service tanlab repozitoriyani ulang.
3. Build Command: npm install
4. Start Command: npm start
5. Render Dashboard > Environment bo‘limida quyidagilarni qo‘shing:
   OPENAI_API_KEY = YANGI, maxfiy OpenAI API kalitingiz
   OPENAI_MODEL = gpt-4.1-mini
6. Deploy qiling. Render bergan URL orqali hamma ilovaga kira oladi; foydalanuvchilarga API kaliti kerak emas.

Eslatma:
- Oldin chatga yuborilgan kalitni darhol bekor qiling va yangisini yarating.
- OpenAI API ishlatish hisobingizdagi tarif bo‘yicha pul sarflashi mumkin. Bepul hosting API sarfini bepul qilmaydi.
- Ommaga ochishdan oldin limit, monitoring va kerak bo‘lsa login/kvota qo‘shing; aks holda boshqalar serveringizdagi API mablag‘ini sarflashi mumkin.
